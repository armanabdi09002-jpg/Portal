package ir.portal.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

/** سرویس پیش‌زمینه که server.py را (با Chaquopy) داخل اپ اجرا می‌کند. */
public class ServerService extends Service {
    private static final String CH = "portal_server";
    private static volatile boolean started = false;
    private PowerManager.WakeLock wl;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "سرور سامانه", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CH);
        } else {
            b = new Notification.Builder(this);
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
         .setContentTitle("سرور سامانه‌ی والدین روشن است")
         .setContentText("برای باز کردن اپ لمس کنید")
         .setContentIntent(pi)
         .setOngoing(true);
        startForeground(1, b.build());

        if (wl == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "portal:server");
            wl.acquire();
        }

        if (!started) {
            started = true;
            new Thread(() -> {
                try {
                    if (!Python.isStarted()) Python.start(new AndroidPlatform(getApplicationContext()));
                    Python py = Python.getInstance();
                    py.getModule("os").get("environ").callAttr("__setitem__", "PORTAL_DATA", getFilesDir().getAbsolutePath());
                    py.getModule("server").callAttr("run_forever");
                } catch (Throwable t) {
                    Log.e("PortalServer", "server stopped", t);
                } finally {
                    started = false;
                }
            }, "portal-server").start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (wl != null && wl.isHeld()) wl.release();
        wl = null;
        new Thread(() -> {
            try {
                if (Python.isStarted()) Python.getInstance().getModule("server").callAttr("stop_server");
            } catch (Throwable t) {
                Log.e("PortalServer", "stop failed", t);
            }
        }).start();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
