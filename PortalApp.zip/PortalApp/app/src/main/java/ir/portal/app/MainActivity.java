package ir.portal.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;

import java.net.InetSocketAddress;
import java.net.Socket;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 1;
    private static final int PORT = 3000;

    private WebView web;
    private SharedPreferences sp;
    private ValueCallback<Uri[]> fileCb;
    private int loadToken = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("portal", MODE_PRIVATE);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) showConnError();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception ex) {
                    fileCb = null;
                    return false;
                }
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("تأیید", (d, w) -> r.confirm())
                        .setNegativeButton("انصراف", (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }

            @Override
            public boolean onJsAlert(WebView v, String url, String msg, JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("باشه", (d, w) -> r.confirm())
                        .setOnCancelListener(d -> r.confirm()).show();
                return true;
            }
        });

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);
        }

        if (sp.getString("mode", null) == null) chooseMode();
        else start();
    }

    private void chooseMode() {
        new AlertDialog.Builder(this)
                .setTitle("این گوشی چه نقشی دارد؟")
                .setItems(new String[]{
                        "سرور است (گوشی معلم)",
                        "به سرور دیگری وصل می‌شود (گوشی والدین)"}, (d, which) -> {
                    if (which == 0) {
                        sp.edit().putString("mode", "server").apply();
                        start();
                    } else {
                        askAddress();
                    }
                })
                .setCancelable(sp.getString("mode", null) != null)
                .show();
    }

    private void askAddress() {
        final EditText in = new EditText(this);
        in.setHint("مثلاً 192.168.1.20");
        in.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        in.setText(sp.getString("addr", ""));
        new AlertDialog.Builder(this)
                .setTitle("آدرس گوشی سرور (روی همان Wi-Fi)")
                .setView(in)
                .setPositiveButton("اتصال", (d, w) -> {
                    String a = in.getText().toString().trim();
                    if (a.isEmpty()) { chooseMode(); return; }
                    sp.edit().putString("mode", "client").putString("addr", a).apply();
                    stopService(new Intent(this, ServerService.class));
                    start();
                })
                .setNegativeButton("بازگشت", (d, w) -> chooseMode())
                .setCancelable(false)
                .show();
    }

    private void start() {
        final int token = ++loadToken;
        web.loadDataWithBaseURL(null,
                "<html dir='rtl'><body style='font-family:sans-serif;text-align:center;margin-top:30vh'>در حال راه‌اندازی…</body></html>",
                "text/html", "utf-8", null);
        if ("server".equals(sp.getString("mode", ""))) {
            Intent i = new Intent(this, ServerService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            new Thread(() -> {
                for (int n = 0; n < 60; n++) {
                    try (Socket k = new Socket()) {
                        k.connect(new InetSocketAddress("127.0.0.1", PORT), 300);
                        break;
                    } catch (Exception ignored) {
                        try { Thread.sleep(500); } catch (InterruptedException e) { return; }
                    }
                }
                runOnUiThread(() -> { if (token == loadToken) web.loadUrl("http://127.0.0.1:" + PORT + "/"); });
            }).start();
        } else {
            String a = sp.getString("addr", "").replace("http://", "").replace("https://", "");
            if (a.endsWith("/")) a = a.substring(0, a.length() - 1);
            if (!a.contains(":")) a = a + ":" + PORT;
            web.loadUrl("http://" + a + "/");
        }
    }

    private void showConnError() {
        boolean server = "server".equals(sp.getString("mode", ""));
        new AlertDialog.Builder(this)
                .setTitle("اتصال برقرار نشد")
                .setMessage(server ? "سرور هنوز آماده نیست." : "به گوشی سرور وصل نشد. آدرس و Wi-Fi را بررسی کنید و مطمئن شوید اپ روی گوشی سرور باز و روشن است.")
                .setPositiveButton("تلاش مجدد", (d, w) -> start())
                .setNeutralButton("تغییر نقش/آدرس", (d, w) -> chooseMode())
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu m) {
        m.add(0, 1, 0, "تغییر نقش / آدرس سرور");
        m.add(0, 2, 1, "بارگذاری مجدد");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem it) {
        if (it.getItemId() == 1) { chooseMode(); return true; }
        if (it.getItemId() == 2) { start(); return true; }
        return super.onOptionsItemSelected(it);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }
}
