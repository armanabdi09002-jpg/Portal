# -*- coding: utf-8 -*-
# سرور کوچک سامانه‌ی والدین به زبان پایتون — فقط با کتابخانه‌ی استاندارد (مناسب Pydroid 3)
# اجرا: این فایل را اجرا کنید، سپس در مرورگر بزنید:  http://localhost:3000
import base64, hmac, json, math, os, re, secrets, socket, tempfile, threading, time, traceback
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(os.environ.get("PORT", "3000"))
TZ = timezone(timedelta(hours=3, minutes=30))        # وقت تهران
STUDENT_CODE = "1797"
TEACHER = {"name": "آرمان عبدی", "pass": "123456"}

try:
    HERE = os.path.dirname(os.path.abspath(__file__))
except NameError:
    HERE = os.getcwd()


def writable(d):
    try:
        p = os.path.join(d, ".write_test")
        with open(p, "w") as f:
            f.write("x")
        os.remove(p)
        return True
    except Exception:
        return False


DATA_DIR = os.environ.get("PORTAL_DATA") or HERE   # در اپ اندروید پوشه‌ی داخلی اپ
if not writable(DATA_DIR):
    for cand in (os.path.expanduser("~"), os.getcwd(), tempfile.gettempdir()):
        if writable(cand):
            DATA_DIR = cand
            break
DATA = os.path.join(DATA_DIR, "data.json")
PAGE = os.path.join(HERE, "parent-portal.html")   # اگر کنار این فایل باشد از همان استفاده می‌شود


LOCK = threading.RLock()
state = {"set": {"from": "06:00", "to": "20:00"}, "students": {}, "homeworks": []}
try:
    with open(DATA, encoding="utf-8") as f:
        loaded = json.load(f)
    state.update(loaded)
except Exception:
    pass
sessions = {}          # token -> {"role":..., "name":...}
tries = {}             # ip -> [count, started_at]


def persist():
    with LOCK:
        tmp = DATA + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(state, f, ensure_ascii=False)
            os.replace(tmp, DATA)
        except Exception as e:
            print("خطا در ذخیره‌ی داده:", e)


# ---------- کمکی‌ها ----------
FA = "۰۱۲۳۴۵۶۷۸۹"
AR = "٠١٢٣٤٥٦٧٨٩"
TABLE = {ord(c): str(i) for i, c in enumerate(FA)}
TABLE.update({ord(c): str(i) for i, c in enumerate(AR)})


def fa2en(s):
    return str(s).translate(TABLE)


def norm(s):
    s = str(s or "").replace("ي", "ی").replace("ك", "ک")
    return re.sub(r"[\u200c\s]+", " ", s).strip()


def now_hm():
    return datetime.now(TZ).strftime("%H:%M")


def in_window(st):
    n = now_hm()
    if st["from"] <= st["to"]:
        return st["from"] <= n <= st["to"]
    return n >= st["from"] or n <= st["to"]


def safe_eq(a, b):
    return hmac.compare_digest(str(a).encode("utf-8"), str(b).encode("utf-8"))


def num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def too_many(ip):
    t = tries.get(ip)
    if not t or time.time() - t[1] > 600:
        tries[ip] = t = [0, time.time()]
    return t[0] >= 10


def failed(ip):
    t = tries.get(ip)
    if t:
        t[0] += 1


def pub_hw(h):
    return {"id": h["id"], "title": h["title"], "desc": h["desc"], "due": h["due"], "showAt": h["showAt"],
            "created": h["created"], "v": h.get("v"), "hasImage": bool(h.get("image"))}


IMG_RE = re.compile(r"^data:image/jpeg;base64,[A-Za-z0-9+/=]+$")
TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")


EMBEDDED_PAGE = (
    "PCFET0NUWVBFIGh0bWw+CjxodG1sIGxhbmc9ImZhIiBkaXI9InJ0bCI+CjxoZWFkPgo8bWV0YSBjaGFyc2V0PSJ1dGYtOCI+Cjxt"
    "ZXRhIG5hbWU9InZpZXdwb3J0IiBjb250ZW50PSJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MSwgdmlld3BvcnQt"
    "Zml0PWNvdmVyIj4KPHRpdGxlPtiz2KfZhdin2YbZhyDZh9mI2LTZhdmG2K8g2YjYp9mE2K/bjNmGPC90aXRsZT4KPGxpbmsgaHJl"
    "Zj0iaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3MyP2ZhbWlseT1WYXppcm1hdG46d2dodEA0MDA7NzAwOzkwMCZkaXNw"
    "bGF5PXN3YXAiIHJlbD0ic3R5bGVzaGVldCI+CjxzdHlsZT4KOnJvb3R7LS1iZzojZWVmM2Y2Oy0tY2FyZDojZmZmOy0taW5rOiMx"
    "NDI5M2E7LS1tdXRlOiM1ZDczODU7LS1saW5lOiNkNmUwZTc7LS1icmFuZDojMGY2ZTdhOy0tYnJhbmQtZDojMGE1MjViOy0tb2s6"
    "IzFmOGE0YzstLW9rYmc6I2UzZjVlYTstLXdhcm46I2IyNmEwMDstLXdhcm5iZzojZmZmMWQ5Oy0tYmFkOiNiMzI2MWU7LS1iYWRi"
    "ZzojZmRlOGU2OwotLWZvbnQ6IlZhemlybWF0biIsVGFob21hLHN5c3RlbS11aSxzYW5zLXNlcmlmO2JveC1zaXppbmc6Ym9yZGVy"
    "LWJveDtwYWRkaW5nLXRvcDplbnYoc2FmZS1hcmVhLWluc2V0LXRvcCwwcHgpO3BhZGRpbmctYm90dG9tOmVudihzYWZlLWFyZWEt"
    "aW5zZXQtYm90dG9tLDBweCl9CkBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6ZGFyayl7OnJvb3R7LS1iZzojMGQxYTIyOy0t"
    "Y2FyZDojMTQyNTJmOy0taW5rOiNlOGYxZjY7LS1tdXRlOiM5YmIzYzI7LS1saW5lOiMyNjQwNGY7LS1icmFuZDojM2ZiNmM0Oy0t"
    "YnJhbmQtZDojN2ZkM2RkOy0tb2tiZzojMTIzNjFmOy0td2FybmJnOiMzYTJhMDg7LS1iYWRiZzojM2QxNzE0Oy0tb2s6IzZmZGM5"
    "YTstLXdhcm46I2ZmYzI2NjstLWJhZDojZmY5YTkyfX0KKiwqOjpiZWZvcmUsKjo6YWZ0ZXJ7Ym94LXNpemluZzppbmhlcml0fQpo"
    "dG1sLGJvZHl7bWFyZ2luOjA7bWluLWhlaWdodDoxMDAlO2JhY2tncm91bmQ6dmFyKC0tYmcpO2NvbG9yOnZhcigtLWluayk7Zm9u"
    "dC1mYW1pbHk6dmFyKC0tZm9udCl9CmJvZHl7ZGlzcGxheTpmbGV4O2p1c3RpZnktY29udGVudDpjZW50ZXJ9Ci5hcHB7d2lkdGg6"
    "MTAwJTttYXgtd2lkdGg6NTYwcHg7cGFkZGluZzoxNnB4IDE0cHggNDBweH0KW2hpZGRlbl17ZGlzcGxheTpub25lIWltcG9ydGFu"
    "dH0KLmNhcmR7YmFja2dyb3VuZDp2YXIoLS1jYXJkKTtib3JkZXI6MXB4IHNvbGlkIHZhcigtLWxpbmUpO2JvcmRlci1yYWRpdXM6"
    "MThweDtwYWRkaW5nOjE4cHg7bWFyZ2luLWJvdHRvbToxMnB4fQpoMXttYXJnaW46MDtmb250LXNpemU6MS41cmVtO2ZvbnQtd2Vp"
    "Z2h0OjkwMH1oMnttYXJnaW46MCAwIDEwcHg7Zm9udC1zaXplOjEuMXJlbX0KcHttYXJnaW46MCAwIDEwcHg7Y29sb3I6dmFyKC0t"
    "bXV0ZSk7bGluZS1oZWlnaHQ6MS44fQouaGVyb3t0ZXh0LWFsaWduOmNlbnRlcjtwYWRkaW5nOjI2cHggMThweH0KLmhlcm8gLmlj"
    "e2ZvbnQtc2l6ZToyLjZyZW19CmxhYmVse2Rpc3BsYXk6YmxvY2s7bWFyZ2luOjEycHggMCA2cHg7Y29sb3I6dmFyKC0tbXV0ZSk7"
    "Zm9udC1zaXplOi45cmVtfQppbnB1dFt0eXBlPXRleHRdLGlucHV0W3R5cGU9cGFzc3dvcmRdLGlucHV0W3R5cGU9dGltZV0saW5w"
    "dXRbdHlwZT10ZWxde3dpZHRoOjEwMCU7bWluLWhlaWdodDo1MHB4O2JvcmRlcjoxcHggc29saWQgdmFyKC0tbGluZSk7Ym9yZGVy"
    "LXJhZGl1czoxMnB4O2JhY2tncm91bmQ6dmFyKC0tYmcpO2NvbG9yOnZhcigtLWluayk7Zm9udDppbmhlcml0O2ZvbnQtc2l6ZTox"
    "LjA1cmVtO3BhZGRpbmc6OHB4IDE0cHh9CmJ1dHRvbntmb250OmluaGVyaXQ7Ym9yZGVyOjA7Ym9yZGVyLXJhZGl1czoxMnB4O21p"
    "bi1oZWlnaHQ6NTBweDtwYWRkaW5nOjEwcHggMTZweDtjdXJzb3I6cG9pbnRlcjtmb250LXdlaWdodDo3MDA7dHJhbnNpdGlvbjp0"
    "cmFuc2Zvcm0gLjFzfQpidXR0b246YWN0aXZle3RyYW5zZm9ybTpzY2FsZSguOTgpfQpidXR0b246Zm9jdXMtdmlzaWJsZSxpbnB1"
    "dDpmb2N1cy12aXNpYmxle291dGxpbmU6M3B4IHNvbGlkIHZhcigtLWJyYW5kKTtvdXRsaW5lLW9mZnNldDoycHh9Ci5wcmltYXJ5"
    "e2JhY2tncm91bmQ6dmFyKC0tYnJhbmQpO2NvbG9yOiNmZmY7d2lkdGg6MTAwJX0ucHJpbWFyeTpob3ZlcntiYWNrZ3JvdW5kOnZh"
    "cigtLWJyYW5kLWQpfQoucHJpbWFyeVtkaXNhYmxlZF17b3BhY2l0eTouNTtjdXJzb3I6bm90LWFsbG93ZWR9Ci5naG9zdHtiYWNr"
    "Z3JvdW5kOnRyYW5zcGFyZW50O2NvbG9yOnZhcigtLWluayk7Ym9yZGVyOjFweCBzb2xpZCB2YXIoLS1saW5lKX0KLm9rLWJ7YmFj"
    "a2dyb3VuZDp2YXIoLS1vayk7Y29sb3I6I2ZmZn0uYmFkLWJ7YmFja2dyb3VuZDp2YXIoLS1iYWQpO2NvbG9yOiNmZmZ9Ci50YWJz"
    "e2Rpc3BsYXk6Z3JpZDtncmlkLXRlbXBsYXRlLWNvbHVtbnM6MWZyIDFmcjtnYXA6NnB4O2JhY2tncm91bmQ6dmFyKC0tYmcpO3Bh"
    "ZGRpbmc6NXB4O2JvcmRlci1yYWRpdXM6MTRweDttYXJnaW4tYm90dG9tOjZweH0KLnRhYnMgYnV0dG9ue2JhY2tncm91bmQ6dHJh"
    "bnNwYXJlbnQ7Y29sb3I6dmFyKC0tbXV0ZSk7bWluLWhlaWdodDo0NHB4fQoudGFicyBidXR0b25bYXJpYS1zZWxlY3RlZD10cnVl"
    "XXtiYWNrZ3JvdW5kOnZhcigtLWNhcmQpO2NvbG9yOnZhcigtLWluayk7Ym94LXNoYWRvdzowIDFweCAzcHggcmdiYSgwLDAsMCwu"
    "MTIpfQoubXNne21pbi1oZWlnaHQ6MS41ZW07bWFyZ2luLXRvcDoxMHB4O2NvbG9yOnZhcigtLWJhZCk7Zm9udC13ZWlnaHQ6NzAw"
    "fQoudG9we2Rpc3BsYXk6ZmxleDthbGlnbi1pdGVtczpjZW50ZXI7anVzdGlmeS1jb250ZW50OnNwYWNlLWJldHdlZW47Z2FwOjEw"
    "cHg7bWFyZ2luLWJvdHRvbToxMnB4fQoudG9wIHNtYWxse2NvbG9yOnZhcigtLW11dGUpO2Rpc3BsYXk6YmxvY2t9Ci5yb3d7ZGlz"
    "cGxheTpncmlkO2dyaWQtdGVtcGxhdGUtY29sdW1uczoxZnIgMWZyO2dhcDoxMHB4fQouc3RhdHtib3JkZXI6MXB4IHNvbGlkIHZh"
    "cigtLWxpbmUpO2JvcmRlci1yYWRpdXM6MTRweDtwYWRkaW5nOjEycHg7dGV4dC1hbGlnbjpjZW50ZXJ9Ci5zdGF0IHNtYWxse2Rp"
    "c3BsYXk6YmxvY2s7Y29sb3I6dmFyKC0tbXV0ZSk7bWFyZ2luLWJvdHRvbTo0cHh9LnN0YXQgYntmb250LXNpemU6MS4xNXJlbX0K"
    "LmNsb2Nre2ZvbnQtc2l6ZToxLjhyZW07Zm9udC13ZWlnaHQ6OTAwO2RpcmVjdGlvbjpsdHI7Zm9udC12YXJpYW50LW51bWVyaWM6"
    "dGFidWxhci1udW1zfQoucGlsbHtkaXNwbGF5OmlubGluZS1ibG9jaztib3JkZXItcmFkaXVzOjk5OXB4O3BhZGRpbmc6NHB4IDEy"
    "cHg7Zm9udC1zaXplOi44NXJlbTtmb250LXdlaWdodDo3MDB9Ci5waWxsLm9re2JhY2tncm91bmQ6dmFyKC0tb2tiZyk7Y29sb3I6"
    "dmFyKC0tb2spfS5waWxsLndhcm57YmFja2dyb3VuZDp2YXIoLS13YXJuYmcpO2NvbG9yOnZhcigtLXdhcm4pfS5waWxsLmJhZHti"
    "YWNrZ3JvdW5kOnZhcigtLWJhZGJnKTtjb2xvcjp2YXIoLS1iYWQpfQoubm90ZXtib3JkZXItcmFkaXVzOjEycHg7cGFkZGluZzox"
    "MnB4O2xpbmUtaGVpZ2h0OjEuODtmb250LXNpemU6Ljk1cmVtfQoubm90ZS5va3tiYWNrZ3JvdW5kOnZhcigtLW9rYmcpO2NvbG9y"
    "OnZhcigtLW9rKX0ubm90ZS53YXJue2JhY2tncm91bmQ6dmFyKC0td2FybmJnKTtjb2xvcjp2YXIoLS13YXJuKX0ubm90ZS5iYWR7"
    "YmFja2dyb3VuZDp2YXIoLS1iYWRiZyk7Y29sb3I6dmFyKC0tYmFkKX0KLmxpc3R7ZGlzcGxheTpncmlkO2dhcDo4cHh9Ci5pdGVt"
    "e2Rpc3BsYXk6ZmxleDthbGlnbi1pdGVtczpjZW50ZXI7anVzdGlmeS1jb250ZW50OnNwYWNlLWJldHdlZW47Z2FwOjhweDtib3Jk"
    "ZXI6MXB4IHNvbGlkIHZhcigtLWxpbmUpO2JvcmRlci1yYWRpdXM6MTRweDtwYWRkaW5nOjEwcHggMTJweH0KLml0ZW0gLm57Zm9u"
    "dC13ZWlnaHQ6NzAwfS5pdGVtIC5ze2NvbG9yOnZhcigtLW11dGUpO2ZvbnQtc2l6ZTouODVyZW19Ci5pdGVtIC5hY3Rze2Rpc3Bs"
    "YXk6ZmxleDtnYXA6NnB4O2ZsZXgtd3JhcDp3cmFwO2p1c3RpZnktY29udGVudDpmbGV4LWVuZH0KLml0ZW0gLmFjdHMgYnV0dG9u"
    "e21pbi1oZWlnaHQ6NDBweDtwYWRkaW5nOjZweCAxMnB4O2ZvbnQtc2l6ZTouOXJlbX0KLmVtcHR5e2NvbG9yOnZhcigtLW11dGUp"
    "O3RleHQtYWxpZ246Y2VudGVyO3BhZGRpbmc6MTRweH0KCnRleHRhcmVhe3dpZHRoOjEwMCU7bWluLWhlaWdodDo5MHB4O3Jlc2l6"
    "ZTp2ZXJ0aWNhbDtib3JkZXI6MXB4IHNvbGlkIHZhcigtLWxpbmUpO2JvcmRlci1yYWRpdXM6MTJweDtiYWNrZ3JvdW5kOnZhcigt"
    "LWJnKTtjb2xvcjp2YXIoLS1pbmspO2ZvbnQ6aW5oZXJpdDtmb250LXNpemU6MXJlbTtsaW5lLWhlaWdodDoxLjg7cGFkZGluZzox"
    "MHB4IDE0cHh9CnRleHRhcmVhOmZvY3VzLXZpc2libGV7b3V0bGluZTozcHggc29saWQgdmFyKC0tYnJhbmQpO291dGxpbmUtb2Zm"
    "c2V0OjJweH0KaW5wdXRbdHlwZT1kYXRldGltZS1sb2NhbF17d2lkdGg6MTAwJTttaW4taGVpZ2h0OjUwcHg7Ym9yZGVyOjFweCBz"
    "b2xpZCB2YXIoLS1saW5lKTtib3JkZXItcmFkaXVzOjEycHg7YmFja2dyb3VuZDp2YXIoLS1iZyk7Y29sb3I6dmFyKC0taW5rKTtm"
    "b250OmluaGVyaXQ7cGFkZGluZzo4cHggMTBweH0KaW5wdXRbdHlwZT1kYXRldGltZS1sb2NhbF06Zm9jdXMtdmlzaWJsZSxpbnB1"
    "dFt0eXBlPWZpbGVdOmZvY3VzLXZpc2libGV7b3V0bGluZTozcHggc29saWQgdmFyKC0tYnJhbmQpO291dGxpbmUtb2Zmc2V0OjJw"
    "eH0KaW5wdXRbdHlwZT1maWxlXXt3aWR0aDoxMDAlO2ZvbnQ6aW5oZXJpdDtjb2xvcjp2YXIoLS1tdXRlKX0KLmh3e2JvcmRlcjox"
    "cHggc29saWQgdmFyKC0tbGluZSk7Ym9yZGVyLXJhZGl1czoxNHB4O3BhZGRpbmc6MTJweH0KLmh3dHtmb250LXdlaWdodDo5MDA7"
    "Zm9udC1zaXplOjEuMDVyZW07bWFyZ2luLWJvdHRvbTo0cHh9Ci5od2R7Y29sb3I6dmFyKC0taW5rKTt3aGl0ZS1zcGFjZTpwcmUt"
    "d3JhcDtsaW5lLWhlaWdodDoxLjk7bWFyZ2luOjhweCAwfQouaHdpbWcsI2hQcmV2e2Rpc3BsYXk6YmxvY2s7d2lkdGg6MTAwJTtt"
    "YXgtaGVpZ2h0OjQyMHB4O29iamVjdC1maXQ6Y29udGFpbjtib3JkZXItcmFkaXVzOjEycHg7YmFja2dyb3VuZDp2YXIoLS1iZyk7"
    "bWFyZ2luLXRvcDo4cHh9Ci5ze2NvbG9yOnZhcigtLW11dGUpO2ZvbnQtc2l6ZTouODVyZW19Ci5od3Jvd3tkaXNwbGF5OmdyaWQ7"
    "Z3JpZC10ZW1wbGF0ZS1jb2x1bW5zOjFmcjtnYXA6MH0KLmh3cm93PmRpdiwucm93PmRpdnttaW4td2lkdGg6MH0KaW5wdXRbdHlw"
    "ZT1kYXRldGltZS1sb2NhbF17bWluLXdpZHRoOjA7bWF4LXdpZHRoOjEwMCV9Ci5hY3RzMntkaXNwbGF5OmZsZXg7ZmxleC13cmFw"
    "OndyYXA7Z2FwOjhweDttYXJnaW4tdG9wOjhweH0KLmFjdHMyIGlucHV0e2ZsZXg6MSAxIDEwMCU7bWluLXdpZHRoOjB9LmFjdHMy"
    "IGJ1dHRvbnttaW4taGVpZ2h0OjQ0cHg7cGFkZGluZzo2cHggMTRweDt3aGl0ZS1zcGFjZTpub3dyYXA7ZmxleDoxfQouYWN0czIg"
    "LmJhZC1ie2ZsZXg6MX0uYWN0czIgLmdob3N0e2ZsZXg6MX0KPC9zdHlsZT4KPC9oZWFkPgo8Ym9keT4KPG1haW4gY2xhc3M9ImFw"
    "cCI+CjxkaXYgY2xhc3M9Im5vdGUgYmFkIiBpZD0ibmV0IiBoaWRkZW4gc3R5bGU9Im1hcmdpbi1ib3R0b206MTBweCI+2KfYsdiq"
    "2KjYp9i3INio2Kcg2LPYsdmI2LEg2YLYt9i5INi02K/ZhyDYp9iz2KrYmyDYr9ixINit2KfZhCDYqtmE2KfYtCDZhdis2K/Yr+KA"
    "pjwvZGl2PgoKPCEtLSDZiNix2YjYryAtLT4KPHNlY3Rpb24gaWQ9ImxvZ2luIj4KICA8ZGl2IGNsYXNzPSJjYXJkIGhlcm8iPgog"
    "ICAgPGRpdiBjbGFzcz0iaWMiPvCfj6s8L2Rpdj4KICAgIDxoMT7Ys9in2YXYp9mG2Ycg2YfZiNi02YXZhtivINmI2KfZhNiv24zZ"
    "hjwvaDE+CiAgICA8cD7YqNix2KfbjCDZiNix2YjYr9iMINmG2YLYtCDYrtmI2K8g2LHYpyDYp9mG2KrYrtin2Kgg2qnZhtuM2K88"
    "L3A+CiAgPC9kaXY+CiAgPGRpdiBjbGFzcz0iY2FyZCI+CiAgICA8ZGl2IGNsYXNzPSJ0YWJzIiByb2xlPSJ0YWJsaXN0Ij4KICAg"
    "ICAgPGJ1dHRvbiByb2xlPSJ0YWIiIGlkPSJ0YWJQIiBhcmlhLXNlbGVjdGVkPSJ0cnVlIj7ZiNin2YTYr9uM2YY8L2J1dHRvbj4K"
    "ICAgICAgPGJ1dHRvbiByb2xlPSJ0YWIiIGlkPSJ0YWJUIiBhcmlhLXNlbGVjdGVkPSJmYWxzZSI+2YXYudmE2YU8L2J1dHRvbj4K"
    "ICAgIDwvZGl2PgogICAgPGZvcm0gaWQ9ImZvcm1QIiBhdXRvY29tcGxldGU9Im9mZiI+CiAgICAgIDxsYWJlbCBmb3I9InNuYW1l"
    "Ij7Zhtin2YUg2Ygg2YbYp9mFINiu2KfZhtmI2KfYr9qv24wg2K/Yp9mG2LTigIzYotmF2YjYsjwvbGFiZWw+CiAgICAgIDxpbnB1"
    "dCBpZD0ic25hbWUiIHR5cGU9InRleHQiIHBsYWNlaG9sZGVyPSLZhdir2YTYp9mLOiDYudmE24wg2LHYttin24zbjCI+CiAgICAg"
    "IDxsYWJlbCBmb3I9InNjb2RlIj7aqdivINmI2LHZiNivINu0INix2YLZhduMPC9sYWJlbD4KICAgICAgPGlucHV0IGlkPSJzY29k"
    "ZSIgdHlwZT0icGFzc3dvcmQiIGlucHV0bW9kZT0ibnVtZXJpYyIgbWF4bGVuZ3RoPSI0IiBwbGFjZWhvbGRlcj0i4oCi4oCi4oCi"
    "4oCiIj4KICAgICAgPGRpdiBjbGFzcz0ibXNnIiBpZD0ibXNnUCIgcm9sZT0iYWxlcnQiPjwvZGl2PgogICAgICA8YnV0dG9uIGNs"
    "YXNzPSJwcmltYXJ5IiB0eXBlPSJzdWJtaXQiPtmI2LHZiNivINio2Ycg2b7ZhtmEINmI2KfZhNiv24zZhjwvYnV0dG9uPgogICAg"
    "PC9mb3JtPgogICAgPGZvcm0gaWQ9ImZvcm1UIiBoaWRkZW4gYXV0b2NvbXBsZXRlPSJvZmYiPgogICAgICA8bGFiZWwgZm9yPSJ0"
    "bmFtZSI+2YbYp9mFINmIINmG2KfZhSDYrtin2YbZiNin2K/ar9uMINmF2LnZhNmFPC9sYWJlbD4KICAgICAgPGlucHV0IGlkPSJ0"
    "bmFtZSIgdHlwZT0idGV4dCI+CiAgICAgIDxsYWJlbCBmb3I9InRwYXNzIj7YsdmF2LIg2LnYqNmI2LE8L2xhYmVsPgogICAgICA8"
    "aW5wdXQgaWQ9InRwYXNzIiB0eXBlPSJwYXNzd29yZCI+CiAgICAgIDxkaXYgY2xhc3M9Im1zZyIgaWQ9Im1zZ1QiIHJvbGU9ImFs"
    "ZXJ0Ij48L2Rpdj4KICAgICAgPGJ1dHRvbiBjbGFzcz0icHJpbWFyeSIgdHlwZT0ic3VibWl0Ij7ZiNix2YjYryDYqNmHINm+2YbZ"
    "hCDZhdi52YTZhTwvYnV0dG9uPgogICAgPC9mb3JtPgogIDwvZGl2Pgo8L3NlY3Rpb24+Cgo8IS0tINm+2YbZhCDZiNin2YTYr9uM"
    "2YYgLS0+CjxzZWN0aW9uIGlkPSJwYXJlbnQiIGhpZGRlbj4KICA8ZGl2IGNsYXNzPSJ0b3AiPjxkaXY+PHNtYWxsPtiu2YjYtCDY"
    "otmF2K/bjNivPC9zbWFsbD48aDEgaWQ9InBTdHVkZW50Ij48L2gxPjwvZGl2PjxidXR0b24gY2xhc3M9Imdob3N0IiBkYXRhLWxv"
    "Z291dD7Yrtix2YjYrDwvYnV0dG9uPjwvZGl2PgogIDxkaXYgY2xhc3M9ImNhcmQiIHN0eWxlPSJ0ZXh0LWFsaWduOmNlbnRlciI+"
    "CiAgICA8c21hbGwgc3R5bGU9ImNvbG9yOnZhcigtLW11dGUpIj7Yqtin2LHbjNiuINin2YXYsdmI2LI8L3NtYWxsPgogICAgPGRp"
    "dj48YiBpZD0icERhdGUiPjwvYj48L2Rpdj4KICAgIDxkaXYgY2xhc3M9ImNsb2NrIiBpZD0icENsb2NrIj4wMDowMDowMDwvZGl2"
    "PgogIDwvZGl2PgogIDxkaXYgY2xhc3M9InJvdyI+CiAgICA8ZGl2IGNsYXNzPSJzdGF0Ij48c21hbGw+8J+UlCDYstmF2KfZhiDZ"
    "gdix2KfYrtmI2KfZhjwvc21hbGw+PGIgaWQ9InBXaW4iPuKAlDwvYj48L2Rpdj4KICAgIDxkaXYgY2xhc3M9InN0YXQiPjxzbWFs"
    "bD7wn5OiINmI2LbYuduM2Kog2YHYsdin2K7ZiNin2YY8L3NtYWxsPjxiIGlkPSJwQ2FsbFN0YXRlIj7YotmF2KfYr9mHPC9iPjwv"
    "ZGl2PgogIDwvZGl2PgogIDxkaXYgY2xhc3M9ImNhcmQiPgogICAgPGgyPvCfjpIg2YjYtti524zYqiDYrdi22YjYsSDYr9ixINqp"
    "2YTYp9izPC9oMj4KICAgIDxkaXYgY2xhc3M9Im5vdGUgd2FybiIgaWQ9InBBdHQiPtmH2YbZiNiyINit2LbZiNixINiv2KfZhti0"
    "4oCM2KLZhdmI2LIg2K/YsSDaqdmE2KfYsyDYq9io2Kog2YbYtNiv2Ycg2KfYs9iqLjwvZGl2PgogIDwvZGl2PgogIDxkaXYgY2xh"
    "c3M9ImNhcmQiPgogICAgPGgyPvCfk5og2Kraqdin2YTbjNmBPC9oMj4KICAgIDxkaXYgY2xhc3M9Imxpc3QiIGlkPSJwSHciPjwv"
    "ZGl2PgogIDwvZGl2PgogIDxkaXYgY2xhc3M9ImNhcmQiPgogICAgPGgyPtmB2LHYp9iu2YjYp9mG24wg2K/Yp9mG2LTigIzYotmF"
    "2YjYsjwvaDI+CiAgICA8cCBpZD0icENhbGxIaW50Ij48L3A+CiAgICA8YnV0dG9uIGNsYXNzPSJwcmltYXJ5IiBpZD0icENhbGxC"
    "dG4iPvCfk6Ig2YHYsdin2K7ZiNin2YbbjCDYr9in2YbYtOKAjNii2YXZiNiyPC9idXR0b24+CiAgPC9kaXY+Cjwvc2VjdGlvbj4K"
    "CjwhLS0g2b7ZhtmEINmF2LnZhNmFIC0tPgo8c2VjdGlvbiBpZD0idGVhY2hlciIgaGlkZGVuPgogIDxkaXYgY2xhc3M9InRvcCI+"
    "PGRpdj48c21hbGw+2YXYudmE2YU8L3NtYWxsPjxoMSBpZD0idFRpdGxlIj48L2gxPjwvZGl2PjxidXR0b24gY2xhc3M9Imdob3N0"
    "IiBkYXRhLWxvZ291dD7Yrtix2YjYrDwvYnV0dG9uPjwvZGl2PgogIDxkaXYgY2xhc3M9ImNhcmQiIHN0eWxlPSJ0ZXh0LWFsaWdu"
    "OmNlbnRlciI+CiAgICA8ZGl2PjxiIGlkPSJ0RGF0ZSI+PC9iPjwvZGl2PjxkaXYgY2xhc3M9ImNsb2NrIiBpZD0idENsb2NrIj4w"
    "MDowMDowMDwvZGl2PgogIDwvZGl2PgogIDxkaXYgY2xhc3M9ImNhcmQiPgogICAgPGgyPvCfk6Ig2YHYsdin2K7ZiNin2YbigIzZ"
    "h9inPC9oMj4KICAgIDxkaXYgY2xhc3M9Imxpc3QiIGlkPSJ0Q2FsbHMiPjwvZGl2PgogIDwvZGl2PgogIDxkaXYgY2xhc3M9ImNh"
    "cmQiPgogICAgPGgyPvCfjpIg2K3YttmI2LEg2Ygg2LrbjNin2Kg8L2gyPgogICAgPHA+2K/Yp9mG2LTigIzYotmF2YjYstin2Ybb"
    "jCDaqdmHINmI2KfZhNiv24zZhti02KfZhiDZiNin2LHYryDYs9in2YXYp9mG2Ycg2LTYr9mH4oCM2KfZhtivINiv2LEg2KfbjNmG"
    "INmB2YfYsdiz2Kog2K/bjNiv2Ycg2YXbjOKAjNi02YjZhtivLjwvcD4KICAgIDxkaXYgY2xhc3M9Imxpc3QiIGlkPSJ0U3R1ZGVu"
    "dHMiPjwvZGl2PgogIDwvZGl2PgogIDxkaXYgY2xhc3M9ImNhcmQiPgogICAgPGgyPvCfk5og2q/YsNin2LTYqtmGINiq2qnZhNuM"
    "2YE8L2gyPgogICAgPGxhYmVsIGZvcj0iaFRpdGxlIj7YudmG2YjYp9mGINiq2qnZhNuM2YE8L2xhYmVsPgogICAgPGlucHV0IGlk"
    "PSJoVGl0bGUiIHR5cGU9InRleHQiIG1heGxlbmd0aD0iMjAwIj4KICAgIDxsYWJlbCBmb3I9ImhEZXNjIj7YqtmI2LbbjNit2KfY"
    "qjwvbGFiZWw+CiAgICA8dGV4dGFyZWEgaWQ9ImhEZXNjIiBtYXhsZW5ndGg9IjQwMDAiPjwvdGV4dGFyZWE+CiAgICA8ZGl2IGNs"
    "YXNzPSJod3JvdyI+CiAgICAgIDxkaXY+PGxhYmVsIGZvcj0iaER1ZSI+2YXZh9mE2Kog2KrYrdmI24zZhDwvbGFiZWw+PGlucHV0"
    "IGlkPSJoRHVlIiB0eXBlPSJkYXRldGltZS1sb2NhbCI+PC9kaXY+CiAgICAgIDxkaXY+PGxhYmVsIGZvcj0iaFNob3ciPtiy2YXY"
    "p9mGINmG2YXYp9uM2LQg2KjZhyDZiNin2YTYr9uM2YY8L2xhYmVsPjxpbnB1dCBpZD0iaFNob3ciIHR5cGU9ImRhdGV0aW1lLWxv"
    "Y2FsIj48L2Rpdj4KICAgIDwvZGl2PgogICAgPGxhYmVsIGZvcj0iaEltZyI+2LnaqdizICjYp9iu2KrbjNin2LHbjCk8L2xhYmVs"
    "PgogICAgPGlucHV0IGlkPSJoSW1nIiB0eXBlPSJmaWxlIiBhY2NlcHQ9ImltYWdlLyoiPgogICAgPGltZyBpZD0iaFByZXYiIGFs"
    "dD0i2b7bjNi04oCM2YbZhdin24zYtCDYudqp2LMiIGhpZGRlbj4KICAgIDxkaXYgY2xhc3M9InMiIGlkPSJoSW1nTm90ZSI+PC9k"
    "aXY+CiAgICA8YnV0dG9uIGNsYXNzPSJnaG9zdCIgaWQ9ImhJbWdDbGVhciIgaGlkZGVuIHN0eWxlPSJtYXJnaW4tdG9wOjhweDt3"
    "aWR0aDoxMDAlIj7Yrdiw2YEg2LnaqdizPC9idXR0b24+CiAgICA8ZGl2IGNsYXNzPSJtc2ciIGlkPSJoTXNnIiByb2xlPSJhbGVy"
    "dCI+PC9kaXY+CiAgICA8ZGl2IGNsYXNzPSJzdGFjayIgc3R5bGU9ImRpc3BsYXk6Z3JpZDtnYXA6OHB4O21hcmdpbi10b3A6NnB4"
    "Ij4KICAgICAgPGJ1dHRvbiBjbGFzcz0icHJpbWFyeSIgaWQ9ImhTZW5kIj7wn5OkINin2LHYs9in2YQg2KraqdmE24zZgSDYqNix"
    "2KfbjCDZh9mF2YfigIzbjCDZiNin2YTYr9uM2YY8L2J1dHRvbj4KICAgICAgPGJ1dHRvbiBjbGFzcz0iZ2hvc3QiIGlkPSJoQ2Fu"
    "Y2VsIiBoaWRkZW4+2KfZhti12LHYp9mBINin2LIg2YjbjNix2KfbjNi0PC9idXR0b24+CiAgICA8L2Rpdj4KICA8L2Rpdj4KICA8"
    "ZGl2IGNsYXNzPSJjYXJkIj4KICAgIDxoMj7wn5OLINiq2qnYp9mE24zZgSDYq9io2KrigIzYtNiv2Yc8L2gyPgogICAgPGRpdiBj"
    "bGFzcz0ibGlzdCIgaWQ9InRIdyI+PC9kaXY+CiAgPC9kaXY+CiAgPGRpdiBjbGFzcz0iY2FyZCI+CiAgICA8aDI+4pqZ77iPINiq"
    "2YbYuNuM2YXYp9iqPC9oMj4KICAgIDxkaXYgY2xhc3M9InJvdyI+CiAgICAgIDxkaXY+PGxhYmVsIGZvcj0id0Zyb20iPti02LHZ"
    "iNi5INmB2LHYp9iu2YjYp9mGPC9sYWJlbD48aW5wdXQgaWQ9IndGcm9tIiB0eXBlPSJ0aW1lIj48L2Rpdj4KICAgICAgPGRpdj48"
    "bGFiZWwgZm9yPSJ3VG8iPtm+2KfbjNin2YYg2YHYsdin2K7ZiNin2YY8L2xhYmVsPjxpbnB1dCBpZD0id1RvIiB0eXBlPSJ0aW1l"
    "Ij48L2Rpdj4KICAgIDwvZGl2PgogICAgPGRpdiBjbGFzcz0ic3RhY2siIHN0eWxlPSJkaXNwbGF5OmdyaWQ7Z2FwOjhweDttYXJn"
    "aW4tdG9wOjEycHgiPgogICAgICA8YnV0dG9uIGNsYXNzPSJwcmltYXJ5IiBpZD0ic2F2ZVNldCI+2LDYrtuM2LHZh+KAjNuMINiq"
    "2YbYuNuM2YXYp9iqPC9idXR0b24+CiAgICA8L2Rpdj4KICAgIDxkaXYgY2xhc3M9Im1zZyIgaWQ9InRTZXRNc2ciIHN0eWxlPSJj"
    "b2xvcjp2YXIoLS1vaykiPjwvZGl2PgogIDwvZGl2Pgo8L3NlY3Rpb24+Cgo8L21haW4+CjxzY3JpcHQ+CmNvbnN0ICQ9aWQ9PmRv"
    "Y3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTsKY29uc3QgZmEyZW49cz0+U3RyaW5nKHMpLnJlcGxhY2UoL1vbsC3buV0vZyxkPT4i"
    "27Dbsduy27PbtNu127bbt9u427kiLmluZGV4T2YoZCkpLnJlcGxhY2UoL1vZoC3ZqV0vZyxkPT4i2aDZodmi2aPZpNml2abZp9mo"
    "2akiLmluZGV4T2YoZCkpOwpjb25zdCB0b0ZhPXM9PlN0cmluZyhzKS5yZXBsYWNlKC9cZC9nLGQ9PiLbsNux27Lbs9u027Xbttu3"
    "27jbuSJbZF0pOwpjb25zdCBlc2M9cz0+cy5yZXBsYWNlKC9bJjw+Il0vZyxjPT4oeyImIjoiJmFtcDsiLCI8IjoiJmx0OyIsIj4i"
    "OiImZ3Q7IiwnIic6IiZxdW90OyJ9W2NdKSk7CmNvbnN0IGZtdERhdGU9KCk9Pm5ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KCJmYS1J"
    "Ui11LWNhLXBlcnNpYW4iLHt3ZWVrZGF5OiJsb25nIix5ZWFyOiJudW1lcmljIixtb250aDoibG9uZyIsZGF5OiJudW1lcmljIn0p"
    "LmZvcm1hdChuZXcgRGF0ZSgpKTsKY29uc3QgQ0FMTF9UWFQ9e3NlbnQ6ItmB2LHYp9iu2YjYp9mGINin2LHYs9in2YQg2LTYr9ib"
    "INmF2YbYqti42LEg2YXYudmE2YUiLGNvbWluZzoi2K/Yp9mG2LTigIzYotmF2YjYsiDYr9ixINit2KfZhCDYotmF2K/ZhiDYp9iz"
    "2KoiLGRvbmU6Itiv2KfZhti04oCM2KLZhdmI2LIg2KrYrdmI24zZhCDYr9in2K/ZhyDYtNivIn07CgovLyA9PT09PT09INin2LHY"
    "qtio2KfYtyDYqNinINiz2LHZiNixID09PT09PT0KY29uc3QgU0tFWT0icGFyZW50UG9ydGFsOnNlc3Npb24iOwpsZXQgc2Vzcz1u"
    "dWxsLFM9bnVsbCxjYWxsRXJyPSIiOwp0cnl7c2Vzcz1KU09OLnBhcnNlKHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oU0tFWSkpfWNh"
    "dGNoKF8pe30KY29uc3Qgc2F2ZVNlc3M9dj0+e3Nlc3M9djt0cnl7dj9zZXNzaW9uU3RvcmFnZS5zZXRJdGVtKFNLRVksSlNPTi5z"
    "dHJpbmdpZnkodikpOnNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0oU0tFWSl9Y2F0Y2goXyl7fX07CmFzeW5jIGZ1bmN0aW9uIGFw"
    "aShwYXRoLGJvZHkpewogIGNvbnN0IHI9YXdhaXQgZmV0Y2gocGF0aCx7bWV0aG9kOmJvZHk/IlBPU1QiOiJHRVQiLGhlYWRlcnM6"
    "eyJDb250ZW50LVR5cGUiOiJhcHBsaWNhdGlvbi9qc29uIiwuLi4oc2Vzcz97QXV0aG9yaXphdGlvbjoiQmVhcmVyICIrc2Vzcy50"
    "b2tlbn06e30pfSxib2R5OmJvZHk/SlNPTi5zdHJpbmdpZnkoYm9keSk6dW5kZWZpbmVkfSk7CiAgbGV0IGo9e307dHJ5e2o9YXdh"
    "aXQgci5qc29uKCl9Y2F0Y2goXyl7fQogIGlmKHIuc3RhdHVzPT09NDAxJiZzZXNzJiZwYXRoIT09Ii9hcGkvbG9naW4iKXtsb2dv"
    "dXQoKTt0aHJvdyBuZXcgRXJyb3IoItmG2LTYs9iqINi02YXYpyDZhdmG2YLYttuMINi02K/YmyDYr9mI2KjYp9ix2Ycg2YjYp9ix"
    "2K8g2LTZiNuM2K8uIil9CiAgaWYoIXIub2spdGhyb3cgbmV3IEVycm9yKGouZXJyb3J8fCLYrti32Kcg2K/YsSDYp9ix2KrYqNin"
    "2Lcg2KjYpyDYs9ix2YjYsSIpOwogIHJldHVybiBqOwp9CmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2goKXsKICBpZighc2VzcylyZXR1"
    "cm47CiAgdHJ5e1M9YXdhaXQgYXBpKCIvYXBpL3N0YXRlIik7JCgibmV0IikuaGlkZGVuPXRydWV9Y2F0Y2goZSl7aWYoc2Vzcykk"
    "KCJuZXQiKS5oaWRkZW49ZmFsc2V9CiAgcmVuZGVyKCk7Cn0Kc2V0SW50ZXJ2YWwocmVmcmVzaCwyMDAwKTsKCi8vID09PT09PT0g"
    "2YjYsdmI2K8gLyDYrtix2YjYrCA9PT09PT09CmNvbnN0IHNob3c9aWQ9PlsibG9naW4iLCJwYXJlbnQiLCJ0ZWFjaGVyIl0uZm9y"
    "RWFjaCh4PT4kKHgpLmhpZGRlbj14IT09aWQpOwpmdW5jdGlvbiB0YWIocCl7JCgiZm9ybVAiKS5oaWRkZW49IXA7JCgiZm9ybVQi"
    "KS5oaWRkZW49cDskKCJ0YWJQIikuc2V0QXR0cmlidXRlKCJhcmlhLXNlbGVjdGVkIixwKTskKCJ0YWJUIikuc2V0QXR0cmlidXRl"
    "KCJhcmlhLXNlbGVjdGVkIiwhcCl9CiQoInRhYlAiKS5vbmNsaWNrPSgpPT50YWIodHJ1ZSk7JCgidGFiVCIpLm9uY2xpY2s9KCk9"
    "PnRhYihmYWxzZSk7CmFzeW5jIGZ1bmN0aW9uIGRvTG9naW4oYm9keSxtc2dFbCl7CiAgbXNnRWwudGV4dENvbnRlbnQ9IiI7CiAg"
    "dHJ5e2NvbnN0IHI9YXdhaXQgYXBpKCIvYXBpL2xvZ2luIixib2R5KTtzYXZlU2VzcyhyKTtlbnRlcigpfWNhdGNoKGUpe21zZ0Vs"
    "LnRleHRDb250ZW50PWUubWVzc2FnZX0KfQokKCJmb3JtUCIpLm9uc3VibWl0PWU9PntlLnByZXZlbnREZWZhdWx0KCk7ZG9Mb2dp"
    "bih7cm9sZToicGFyZW50IixuYW1lOiQoInNuYW1lIikudmFsdWUsY29kZTokKCJzY29kZSIpLnZhbHVlfSwkKCJtc2dQIikpfTsK"
    "JCgiZm9ybVQiKS5vbnN1Ym1pdD1lPT57ZS5wcmV2ZW50RGVmYXVsdCgpO2RvTG9naW4oe3JvbGU6InRlYWNoZXIiLG5hbWU6JCgi"
    "dG5hbWUiKS52YWx1ZSxwYXNzOiQoInRwYXNzIikudmFsdWV9LCQoIm1zZ1QiKSl9OwpmdW5jdGlvbiBsb2dvdXQoKXtzYXZlU2Vz"
    "cyhudWxsKTtTPW51bGw7WyJzbmFtZSIsInNjb2RlIiwidG5hbWUiLCJ0cGFzcyJdLmZvckVhY2goaT0+JChpKS52YWx1ZT0iIik7"
    "c2hvdygibG9naW4iKX0KZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgiW2RhdGEtbG9nb3V0XSIpLmZvckVhY2goYj0+Yi5vbmNs"
    "aWNrPWxvZ291dCk7CgovLyA9PT09PT09INm+2YbZhCDZiNin2YTYr9uM2YYgPT09PT09PQpjb25zdCBpbldpbmRvdz0oc2V0LG4p"
    "PT5zZXQuZnJvbTw9c2V0LnRvPyhuPj1zZXQuZnJvbSYmbjw9c2V0LnRvKToobj49c2V0LmZyb218fG48PXNldC50byk7CmZ1bmN0"
    "aW9uIHJlbmRlclBhcmVudCgpewogIGlmKCFTfHwhUy5tZSlyZXR1cm47CiAgY29uc3QgbWU9Uy5tZTsKICAkKCJwU3R1ZGVudCIp"
    "LnRleHRDb250ZW50PXNlc3MubmFtZTtyZW5kZXJQSHcoKTskKCJwRGF0ZSIpLnRleHRDb250ZW50PWZtdERhdGUoKTsKICAkKCJw"
    "V2luIikudGV4dENvbnRlbnQ9dG9GYShTLnNldC5mcm9tKSsiINiq2KcgIit0b0ZhKFMuc2V0LnRvKTsKICBjb25zdCBhPSQoInBB"
    "dHQiKTsKICBpZihtZS5wcmVzZW50PT09dHJ1ZSl7YS5jbGFzc05hbWU9Im5vdGUgb2siO2EudGV4dENvbnRlbnQ9IvCfjokg2K3Y"
    "ttmI2LEg2K/Yp9mG2LTigIzYotmF2YjYsiDYq9io2Kog2LTYry4g2K/Yp9mG2LTigIzYotmF2YjYsiDYr9ixINqp2YTYp9izINit"
    "2KfYttixINin2LPYqi4ifQogIGVsc2UgaWYobWUucHJlc2VudD09PWZhbHNlKXthLmNsYXNzTmFtZT0ibm90ZSBiYWQiO2EudGV4"
    "dENvbnRlbnQ9Itiv2KfZhti04oCM2KLZhdmI2LIg2K/YsSDaqdmE2KfYsyDYutin24zYqCDYq9io2Kog2LTYr9mHINin2LPYqi4i"
    "fQogIGVsc2V7YS5jbGFzc05hbWU9Im5vdGUgd2FybiI7YS50ZXh0Q29udGVudD0i2YfZhtmI2LIg2K3YttmI2LEg2K/Yp9mG2LTi"
    "gIzYotmF2YjYsiDYr9ixINqp2YTYp9izINir2KjYqiDZhti02K/ZhyDYp9iz2KouIn0KICBjb25zdCBjPW1lLmNhbGw7CiAgJCgi"
    "cENhbGxTdGF0ZSIpLnRleHRDb250ZW50PWM/Q0FMTF9UWFRbYy5zdGF0dXNdLnNwbGl0KCLYmyIpWzBdOiLYotmF2KfYr9mHIjsK"
    "ICBsZXQgaGludD0iIixjYW49dHJ1ZTsKICBpZihjJiZjLnN0YXR1cyE9PSJkb25lIil7aGludD1DQUxMX1RYVFtjLnN0YXR1c107"
    "Y2FuPWZhbHNlfQogIGVsc2UgaWYoIWluV2luZG93KFMuc2V0LFMubm93KSl7aGludD0i2YHYsdin2K7ZiNin2YYg2YHZgti3INiv"
    "2LEg2KjYp9iy2YfigIzbjCAiK3RvRmEoUy5zZXQuZnJvbSkrIiDYqtinICIrdG9GYShTLnNldC50bykrIiDZgdi52KfZhCDYp9iz"
    "2KouIjtjYW49ZmFsc2V9CiAgZWxzZSBoaW50PWMmJmMuc3RhdHVzPT09ImRvbmUiPyLZhduM4oCM2KrZiNin2YbbjNivINiv2YjY"
    "qNin2LHZhyDZgdix2KfYrtmI2KfZhiDYqNiv2YfbjNivLiI6Itio2LHYp9uMINin2LHYs9in2YQg2YHYsdin2K7ZiNin2YYg2K/a"
    "qdmF2YfigIzbjCDYstuM2LEg2LHYpyDYqNiy2YbbjNivLiI7CiAgJCgicENhbGxIaW50IikudGV4dENvbnRlbnQ9Y2FsbEVycnx8"
    "aGludDskKCJwQ2FsbEJ0biIpLmRpc2FibGVkPSFjYW47Cn0KJCgicENhbGxCdG4iKS5vbmNsaWNrPWFzeW5jKCk9PnsKICBjYWxs"
    "RXJyPSIiOwogIHRyeXthd2FpdCBhcGkoIi9hcGkvY2FsbCIse30pO31jYXRjaChlKXtjYWxsRXJyPWUubWVzc2FnZX0KICByZWZy"
    "ZXNoKCk7Cn07CgovLyA9PT09PT09INm+2YbZhCDZhdi52YTZhSA9PT09PT09CmZ1bmN0aW9uIHJlbmRlclRlYWNoZXIoKXsKICBp"
    "ZighU3x8IVMuc3R1ZGVudHMpcmV0dXJuOwogICQoInRUaXRsZSIpLnRleHRDb250ZW50PXNlc3MubmFtZTskKCJ0RGF0ZSIpLnRl"
    "eHRDb250ZW50PWZtdERhdGUoKTtyZW5kZXJUSHcoKTsKICBjb25zdCBuYW1lcz1PYmplY3Qua2V5cyhTLnN0dWRlbnRzKTsKICBj"
    "b25zdCBjYWxscz1uYW1lcy5maWx0ZXIobj0+Uy5zdHVkZW50c1tuXS5jYWxsJiZTLnN0dWRlbnRzW25dLmNhbGwuc3RhdHVzIT09"
    "ImRvbmUiKTsKICBzZXRIVE1MKCQoInRDYWxscyIpLGNhbGxzLmxlbmd0aD9jYWxscy5tYXAobj0+ewogICAgY29uc3QgYz1TLnN0"
    "dWRlbnRzW25dLmNhbGw7CiAgICByZXR1cm4gYDxkaXYgY2xhc3M9Iml0ZW0iPjxkaXY+PGRpdiBjbGFzcz0ibiI+JHtlc2Mobil9"
    "PC9kaXY+PGRpdiBjbGFzcz0icyI+JHtDQUxMX1RYVFtjLnN0YXR1c119PC9kaXY+PC9kaXY+CiAgICA8ZGl2IGNsYXNzPSJhY3Rz"
    "Ij4ke2Muc3RhdHVzPT09InNlbnQiP2A8YnV0dG9uIGNsYXNzPSJvay1iIiBkYXRhLWFjdD0iY29taW5nIiBkYXRhLW49IiR7ZXNj"
    "KG4pfSI+2K/YsSDYrdin2YQg2YHYsdiz2KrYp9iv2YY8L2J1dHRvbj5gOiIifQogICAgPGJ1dHRvbiBjbGFzcz0icHJpbWFyeSIg"
    "c3R5bGU9IndpZHRoOmF1dG8iIGRhdGEtYWN0PSJkb25lIiBkYXRhLW49IiR7ZXNjKG4pfSI+2KrYrdmI24zZhCDYtNivPC9idXR0"
    "b24+PC9kaXY+PC9kaXY+YH0pLmpvaW4oIiIpOic8ZGl2IGNsYXNzPSJlbXB0eSI+2YHYsdin2K7ZiNin2YYg2YHYudin2YTbjCDZ"
    "iNis2YjYryDZhtiv2KfYsdivLjwvZGl2PicpOwogIHNldEhUTUwoJCgidFN0dWRlbnRzIiksbmFtZXMubGVuZ3RoP25hbWVzLm1h"
    "cChuPT57CiAgICBjb25zdCBwPVMuc3R1ZGVudHNbbl0ucHJlc2VudDsKICAgIHJldHVybiBgPGRpdiBjbGFzcz0iaXRlbSI+PGRp"
    "dj48ZGl2IGNsYXNzPSJuIj4ke2VzYyhuKX08L2Rpdj48c3BhbiBjbGFzcz0icGlsbCAke3A9PT10cnVlPyJvayI6cD09PWZhbHNl"
    "PyJiYWQiOiJ3YXJuIn0iPiR7cD09PXRydWU/Itit2KfYttixIjpwPT09ZmFsc2U/Iti62KfbjNioIjoi2KvYqNiqINmG2LTYr9mH"
    "In08L3NwYW4+PC9kaXY+CiAgICA8ZGl2IGNsYXNzPSJhY3RzIj48YnV0dG9uIGNsYXNzPSJvay1iIiBkYXRhLWFjdD0iaGVyZSIg"
    "ZGF0YS1uPSIke2VzYyhuKX0iPtit2KfYttixPC9idXR0b24+PGJ1dHRvbiBjbGFzcz0iYmFkLWIiIGRhdGEtYWN0PSJhd2F5IiBk"
    "YXRhLW49IiR7ZXNjKG4pfSI+2LrYp9uM2Kg8L2J1dHRvbj48L2Rpdj48L2Rpdj5gfSkuam9pbigiIik6JzxkaXYgY2xhc3M9ImVt"
    "cHR5Ij7Zh9mG2YjYsiDYr9in2YbYtOKAjNii2YXZiNiy24wg2YjYp9ix2K8g2YbYtNiv2Ycg2KfYs9iqLjwvZGl2PicpOwp9CmRv"
    "Y3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoImNsaWNrIixhc3luYyBlPT57CiAgY29uc3QgYj1lLnRhcmdldC5jbG9zZXN0KCJbZGF0"
    "YS1hY3RdIik7aWYoIWIpcmV0dXJuOwogIHRyeXthd2FpdCBhcGkoIi9hcGkvc3R1ZGVudCIse25hbWU6Yi5kYXRhc2V0Lm4sYWN0"
    "aW9uOmIuZGF0YXNldC5hY3R9KX1jYXRjaChfKXt9CiAgcmVmcmVzaCgpOwp9KTsKZnVuY3Rpb24gZmlsbFNldHRpbmdzKCl7JCgi"
    "d0Zyb20iKS52YWx1ZT1TLnNldC5mcm9tOyQoIndUbyIpLnZhbHVlPVMuc2V0LnRvfQpjb25zdCB0bXNnPSh0LGMpPT57JCgidFNl"
    "dE1zZyIpLnN0eWxlLmNvbG9yPWM7JCgidFNldE1zZyIpLnRleHRDb250ZW50PXR9OwokKCJzYXZlU2V0Iikub25jbGljaz1hc3lu"
    "YygpPT57CiAgdHJ5e2F3YWl0IGFwaSgiL2FwaS9zZXR0aW5ncyIse2Zyb206JCgid0Zyb20iKS52YWx1ZSx0bzokKCJ3VG8iKS52"
    "YWx1ZX0pO3Rtc2coItiq2YbYuNuM2YXYp9iqINiw2K7bjNix2Ycg2LTYry4iLCJ2YXIoLS1vaykiKTtzZXRUaW1lb3V0KCgpPT50"
    "bXNnKCIiLCIiKSwyMDAwKX0KICBjYXRjaChlKXt0bXNnKGUubWVzc2FnZSwidmFyKC0tYmFkKSIpfQp9OwoKCi8vID09PT09PT0g"
    "2Kraqdin2YTbjNmBID09PT09PT0KY29uc3Qgc2V0SFRNTD0oZWwsaCk9PntpZihlbC5faCE9PWgpe2VsLl9oPWg7ZWwuaW5uZXJI"
    "VE1MPWg7cmV0dXJuIHRydWV9cmV0dXJuIGZhbHNlfTsKY29uc3QgcGFkMj1uPT5TdHJpbmcobikucGFkU3RhcnQoMiwiMCIpOwpj"
    "b25zdCBmbXREVD1tcz0+bmV3IEludGwuRGF0ZVRpbWVGb3JtYXQoImZhLUlSLXUtY2EtcGVyc2lhbiIse3llYXI6Im51bWVyaWMi"
    "LG1vbnRoOiJsb25nIixkYXk6Im51bWVyaWMiLGhvdXI6IjItZGlnaXQiLG1pbnV0ZToiMi1kaWdpdCJ9KS5mb3JtYXQobmV3IERh"
    "dGUobXMpKTsKY29uc3QgdG9Mb2NhbElucHV0PW1zPT57Y29uc3QgZD1uZXcgRGF0ZShtcyk7cmV0dXJuIGQuZ2V0RnVsbFllYXIo"
    "KSsiLSIrcGFkMihkLmdldE1vbnRoKCkrMSkrIi0iK3BhZDIoZC5nZXREYXRlKCkpKyJUIitwYWQyKGQuZ2V0SG91cnMoKSkrIjoi"
    "K3BhZDIoZC5nZXRNaW51dGVzKCkpfTsKY29uc3QgZnJvbUxvY2FsSW5wdXQ9dj0+dj9uZXcgRGF0ZSh2KS5nZXRUaW1lKCk6TmFO"
    "OwpmdW5jdGlvbiBkdWVJbmZvKG1zKXsKICBjb25zdCBkaWZmPW1zLURhdGUubm93KCk7aWYoZGlmZjwwKXJldHVybntjbHM6ImJh"
    "ZCIsdDoi2YXZh9mE2Kog2KrZhdin2YUg2LTYr9mHIn07CiAgY29uc3QgbT1NYXRoLmZsb29yKGRpZmYvNjAwMDApLGQ9TWF0aC5m"
    "bG9vcihtLzE0NDApLGg9TWF0aC5mbG9vcigobSUxNDQwKS82MCk7CiAgY29uc3QgdD1kPjA/dG9GYShkKSsiINix2YjYsiDZiCAi"
    "K3RvRmEoaCkrIiDYs9in2LnYqiDZhdin2YbYr9mHIjpoPjA/dG9GYShoKSsiINiz2KfYudiqINmIICIrdG9GYShtJTYwKSsiINiv"
    "2YLbjNmC2Ycg2YXYp9mG2K/ZhyI6dG9GYShtKSsiINiv2YLbjNmC2Ycg2YXYp9mG2K/ZhyI7CiAgcmV0dXJue2NsczpkPj0xPyJv"
    "ayI6Indhcm4iLHR9Owp9CmZ1bmN0aW9uIGh3UGFyZW50SFRNTChsaXN0KXsKICBpZighbGlzdC5sZW5ndGgpcmV0dXJuICc8ZGl2"
    "IGNsYXNzPSJlbXB0eSI+2KraqdmE24zZgduMINir2KjYqiDZhti02K/ZhyDYp9iz2KouPC9kaXY+JzsKICByZXR1cm4gbGlzdC5t"
    "YXAoaD0+e2NvbnN0IGRpPWR1ZUluZm8oaC5kdWUpOwogICAgcmV0dXJuIGA8ZGl2IGNsYXNzPSJodyI+PGRpdiBjbGFzcz0iaHd0"
    "Ij4ke2VzYyhoLnRpdGxlKX08L2Rpdj48ZGl2IGNsYXNzPSJzIj7wn5OFINmF2YfZhNiqINiq2K3ZiNuM2YQ6ICR7Zm10RFQoaC5k"
    "dWUpfSA8c3BhbiBjbGFzcz0icGlsbCAke2RpLmNsc30iPiR7ZGkudH08L3NwYW4+PC9kaXY+JHtoLmRlc2M/YDxwIGNsYXNzPSJo"
    "d2QiPiR7ZXNjKGguZGVzYyl9PC9wPmA6IiJ9JHtpbWdUYWcoaCl9PC9kaXY+YH0pLmpvaW4oIiIpOwp9CmZ1bmN0aW9uIGh3VGVh"
    "Y2hlckhUTUwobGlzdCl7CiAgaWYoIWxpc3QubGVuZ3RoKXJldHVybiAnPGRpdiBjbGFzcz0iZW1wdHkiPtmH2YbZiNiyINiq2qnZ"
    "hNuM2YHbjCDZhtqv2LDYp9i02KrZh+KAjNin24zYry48L2Rpdj4nOwogIHJldHVybiBsaXN0Lm1hcChoPT57Y29uc3QgdmlzPWgu"
    "c2hvd0F0PD1EYXRlLm5vdygpOwogICAgcmV0dXJuIGA8ZGl2IGNsYXNzPSJodyI+PGRpdiBjbGFzcz0iaHd0Ij4ke2VzYyhoLnRp"
    "dGxlKX08L2Rpdj48ZGl2IGNsYXNzPSJzIj7wn5OFINmF2YfZhNiqINiq2K3ZiNuM2YQ6ICR7Zm10RFQoaC5kdWUpfTwvZGl2Pgog"
    "ICAgPGRpdiBzdHlsZT0ibWFyZ2luOjZweCAwIj48c3BhbiBjbGFzcz0icGlsbCAke3Zpcz8ib2siOiJ3YXJuIn0iPiR7dmlzPyLY"
    "qNix2KfbjCDZiNin2YTYr9uM2YYg2YbZhdin24zYtCDYr9in2K/ZhyDZhduM4oCM2LTZiNivIjoi2LLZhdin2YbigIzYqNmG2K/b"
    "jOKAjNi02K/ZhzogIitmbXREVChoLnNob3dBdCl9PC9zcGFuPjwvZGl2PgogICAgPGRpdiBjbGFzcz0icyI+2KrYutuM24zYsSDY"
    "stmF2KfZhiDZhtmF2KfbjNi0OjwvZGl2PgogICAgPGRpdiBjbGFzcz0iYWN0czIiPjxpbnB1dCB0eXBlPSJkYXRldGltZS1sb2Nh"
    "bCIgYXJpYS1sYWJlbD0i2LLZhdin2YYg2YbZhdin24zYtCIgdmFsdWU9IiR7dG9Mb2NhbElucHV0KGguc2hvd0F0KX0iIGRhdGEt"
    "c2hvd2luPSIke2guaWR9Ij48YnV0dG9uIGNsYXNzPSJnaG9zdCIgZGF0YS1od3Nob3c9IiR7aC5pZH0iPtir2KjYqjwvYnV0dG9u"
    "PjwvZGl2PgogICAgPGRpdiBjbGFzcz0iYWN0czIiPjxidXR0b24gY2xhc3M9Imdob3N0IiBkYXRhLWh3ZWRpdD0iJHtoLmlkfSI+"
    "2YjbjNix2KfbjNi0PC9idXR0b24+PGJ1dHRvbiBjbGFzcz0iYmFkLWIiIGRhdGEtaHdkZWw9IiR7aC5pZH0iPtit2LDZgTwvYnV0"
    "dG9uPjwvZGl2PjwvZGl2PmB9KS5qb2luKCIiKTsKfQpsZXQgaHdBbGw9W10sZWRpdGluZ0lkPW51bGwsaW1nPXttb2RlOiJub25l"
    "IixkYXRhOm51bGx9Owpjb25zdCBobXNnPSh0LGMpPT57JCgiaE1zZyIpLnN0eWxlLmNvbG9yPWM7JCgiaE1zZyIpLnRleHRDb250"
    "ZW50PXR9OwpmdW5jdGlvbiByZXNpemVJbWcoZmlsZSl7cmV0dXJuIG5ldyBQcm9taXNlKChyZXMscmVqKT0+e2NvbnN0IGZyPW5l"
    "dyBGaWxlUmVhZGVyKCk7ZnIub25lcnJvcj1yZWo7ZnIub25sb2FkPSgpPT57Y29uc3QgaW09bmV3IEltYWdlKCk7aW0ub25lcnJv"
    "cj1yZWo7aW0ub25sb2FkPSgpPT57CiAgY29uc3Qgaz1NYXRoLm1pbigxLDkwMC9NYXRoLm1heChpbS53aWR0aCxpbS5oZWlnaHQp"
    "KSxjPWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoImNhbnZhcyIpO2Mud2lkdGg9TWF0aC5yb3VuZChpbS53aWR0aCprKTtjLmhlaWdo"
    "dD1NYXRoLnJvdW5kKGltLmhlaWdodCprKTsKICBjb25zdCB4PWMuZ2V0Q29udGV4dCgiMmQiKTt4LmZpbGxTdHlsZT0iI2ZmZiI7"
    "eC5maWxsUmVjdCgwLDAsYy53aWR0aCxjLmhlaWdodCk7eC5kcmF3SW1hZ2UoaW0sMCwwLGMud2lkdGgsYy5oZWlnaHQpO3Jlcyhj"
    "LnRvRGF0YVVSTCgiaW1hZ2UvanBlZyIsLjcyKSl9O2ltLnNyYz1mci5yZXN1bHR9O2ZyLnJlYWRBc0RhdGFVUkwoZmlsZSl9KX0K"
    "ZnVuY3Rpb24gc2V0SW1nVUkoKXsKICAkKCJoUHJldiIpLmhpZGRlbj0hKGltZy5tb2RlPT09Im5ldyIpO2lmKGltZy5tb2RlPT09"
    "Im5ldyIpJCgiaFByZXYiKS5zcmM9aW1nLmRhdGE7CiAgJCgiaEltZ05vdGUiKS50ZXh0Q29udGVudD1pbWcubW9kZT09PSJrZWVw"
    "Ij8i2LnaqdizINmB2LnZhNuMINiq2qnZhNuM2YEg2K3Zgdi4INmF24zigIzYtNmI2K8uIjoiIjsKICAkKCJoSW1nQ2xlYXIiKS5o"
    "aWRkZW49aW1nLm1vZGU9PT0ibm9uZSI7Cn0KZnVuY3Rpb24gcmVzZXRId0Zvcm0oKXsKICBlZGl0aW5nSWQ9bnVsbDtpbWc9e21v"
    "ZGU6Im5vbmUiLGRhdGE6bnVsbH07CiAgJCgiaFRpdGxlIikudmFsdWU9IiI7JCgiaERlc2MiKS52YWx1ZT0iIjskKCJoSW1nIiku"
    "dmFsdWU9IiI7CiAgJCgiaFNob3ciKS52YWx1ZT10b0xvY2FsSW5wdXQoRGF0ZS5ub3coKSk7JCgiaER1ZSIpLnZhbHVlPXRvTG9j"
    "YWxJbnB1dChEYXRlLm5vdygpKzI0KjM2MDBlMyk7CiAgJCgiaFNlbmQiKS50ZXh0Q29udGVudD0i8J+TpCDYp9ix2LPYp9mEINiq"
    "2qnZhNuM2YEg2KjYsdin24wg2YfZhdmH4oCM24wg2YjYp9mE2K/bjNmGIjskKCJoQ2FuY2VsIikuaGlkZGVuPXRydWU7c2V0SW1n"
    "VUkoKTsKfQokKCJoQ2FuY2VsIikub25jbGljaz0oKT0+e3Jlc2V0SHdGb3JtKCk7aG1zZygiIiwiIil9OwokKCJoSW1nIikub25j"
    "aGFuZ2U9YXN5bmMgZT0+ewogIGNvbnN0IGY9ZS50YXJnZXQuZmlsZXNbMF07aWYoIWYpcmV0dXJuOwogIHRyeXtpbWc9e21vZGU6"
    "Im5ldyIsZGF0YTphd2FpdCByZXNpemVJbWcoZil9O3NldEltZ1VJKCk7aG1zZygiIiwiIil9Y2F0Y2goXyl7aG1zZygi2K7ZiNin"
    "2YbYr9mGINi52qnYsyDZhdmF2qnZhiDZhti02K8uIiwidmFyKC0tYmFkKSIpfQp9OwokKCJoSW1nQ2xlYXIiKS5vbmNsaWNrPSgp"
    "PT57aW1nPXttb2RlOiJub25lIixkYXRhOm51bGx9OyQoImhJbWciKS52YWx1ZT0iIjtzZXRJbWdVSSgpfTsKJCgiaFNlbmQiKS5v"
    "bmNsaWNrPWFzeW5jKCk9PnsKICBjb25zdCB0aXRsZT0kKCJoVGl0bGUiKS52YWx1ZS50cmltKCksZGVzYz0kKCJoRGVzYyIpLnZh"
    "bHVlLnRyaW0oKSxkdWU9ZnJvbUxvY2FsSW5wdXQoJCgiaER1ZSIpLnZhbHVlKSxzaG93QXQ9ZnJvbUxvY2FsSW5wdXQoJCgiaFNo"
    "b3ciKS52YWx1ZSk7CiAgaWYoIXRpdGxlKXJldHVybiBobXNnKCLYudmG2YjYp9mGINiq2qnZhNuM2YEg2LHYpyDZiNin2LHYryDa"
    "qdmG24zYry4iLCJ2YXIoLS1iYWQpIik7CiAgaWYoaXNOYU4oZHVlKSlyZXR1cm4gaG1zZygi2YXZh9mE2Kog2KrYrdmI24zZhCDY"
    "sdinINmF2LTYrti1INqp2YbbjNivLiIsInZhcigtLWJhZCkiKTsKICBpZihpc05hTihzaG93QXQpKXJldHVybiBobXNnKCLYstmF"
    "2KfZhiDZhtmF2KfbjNi0INix2Kcg2YXYtNiu2LUg2qnZhtuM2K8uIiwidmFyKC0tYmFkKSIpOwogIGNvbnN0IHA9e3RpdGxlLGRl"
    "c2MsZHVlLHNob3dBdH07CiAgaWYoZWRpdGluZ0lkKXAuaWQ9ZWRpdGluZ0lkOwogIGlmKGltZy5tb2RlPT09Im5ldyIpcC5pbWFn"
    "ZT1pbWcuZGF0YTtlbHNlIGlmKGltZy5tb2RlPT09Im5vbmUiKXAuaW1hZ2U9bnVsbDsKICAkKCJoU2VuZCIpLmRpc2FibGVkPXRy"
    "dWU7CiAgdHJ5ewogICAgYXdhaXQgaHdPcHMuc2F2ZShwKTsKICAgIGNvbnN0IGxhdGVyPXNob3dBdD5EYXRlLm5vdygpOwogICAg"
    "cmVzZXRId0Zvcm0oKTtobXNnKGxhdGVyPyLYsNiu24zYsdmHINi02K/YmyDYr9ixINiy2YXYp9mGINiq2LnbjNuM2YbigIzYtNiv"
    "2Ycg2KjYsdin24wg2YjYp9mE2K/bjNmGINmG2YXYp9uM2LQg2K/Yp9iv2Ycg2YXbjOKAjNi02YjYry4iOiLYqtqp2YTbjNmBINio"
    "2LHYp9uMINmH2YXZh+KAjNuMINmI2KfZhNiv24zZhiDYp9ix2LPYp9mEINi02K8uIiwidmFyKC0tb2spIik7CiAgICBzZXRUaW1l"
    "b3V0KCgpPT5obXNnKCIiLCIiKSwzNTAwKTtyZWZyZXNoKCk7CiAgfWNhdGNoKGUpe2htc2coZS5tZXNzYWdlLCJ2YXIoLS1iYWQp"
    "Iil9CiAgZmluYWxseXskKCJoU2VuZCIpLmRpc2FibGVkPWZhbHNlfQp9Owpkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCJjbGlj"
    "ayIsYXN5bmMgZT0+ewogIGxldCBiPWUudGFyZ2V0LmNsb3Nlc3QoIltkYXRhLWh3c2hvd10iKTsKICBpZihiKXtjb25zdCBpZD1i"
    "LmRhdGFzZXQuaHdzaG93LGlucD1kb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdbZGF0YS1zaG93aW49IicraWQrJyJdJyksbXM9ZnJv"
    "bUxvY2FsSW5wdXQoaW5wJiZpbnAudmFsdWUpOwogICAgaWYoaXNOYU4obXMpKXJldHVybjt0cnl7YXdhaXQgaHdPcHMuc2hvdyhp"
    "ZCxtcyl9Y2F0Y2goZXJyKXtobXNnKGVyci5tZXNzYWdlLCJ2YXIoLS1iYWQpIil9cmVmcmVzaCgpO3JldHVybn0KICBiPWUudGFy"
    "Z2V0LmNsb3Nlc3QoIltkYXRhLWh3ZGVsXSIpOwogIGlmKGIpe2lmKCFjb25maXJtKCLYp9uM2YYg2KraqdmE24zZgSDYrdiw2YEg"
    "2LTZiNiv2J8iKSlyZXR1cm47dHJ5e2F3YWl0IGh3T3BzLmRlbChiLmRhdGFzZXQuaHdkZWwpfWNhdGNoKGVycil7aG1zZyhlcnIu"
    "bWVzc2FnZSwidmFyKC0tYmFkKSIpfXJlZnJlc2goKTtyZXR1cm59CiAgYj1lLnRhcmdldC5jbG9zZXN0KCJbZGF0YS1od2VkaXRd"
    "Iik7CiAgaWYoYil7Y29uc3QgaD1od0FsbC5maW5kKHg9PnguaWQ9PT1iLmRhdGFzZXQuaHdlZGl0KTtpZighaClyZXR1cm47CiAg"
    "ICBlZGl0aW5nSWQ9aC5pZDskKCJoVGl0bGUiKS52YWx1ZT1oLnRpdGxlOyQoImhEZXNjIikudmFsdWU9aC5kZXNjfHwiIjskKCJo"
    "RHVlIikudmFsdWU9dG9Mb2NhbElucHV0KGguZHVlKTskKCJoU2hvdyIpLnZhbHVlPXRvTG9jYWxJbnB1dChoLnNob3dBdCk7CiAg"
    "ICAkKCJoSW1nIikudmFsdWU9IiI7aW1nPWh3SGFzSW1hZ2UoaCk/e21vZGU6ImtlZXAiLGRhdGE6bnVsbH06e21vZGU6Im5vbmUi"
    "LGRhdGE6bnVsbH07c2V0SW1nVUkoKTsKICAgICQoImhTZW5kIikudGV4dENvbnRlbnQ9IvCfkr4g2LDYrtuM2LHZh+KAjNuMINiq"
    "2LrbjNuM2LHYp9iqINiq2qnZhNuM2YEiOyQoImhDYW5jZWwiKS5oaWRkZW49ZmFsc2U7aG1zZygi2K/YsSDYrdin2YQg2YjbjNix"
    "2KfbjNi0IMKrIitoLnRpdGxlKyLCuyIsInZhcigtLW11dGUpIik7CiAgICAkKCJoVGl0bGUiKS5zY3JvbGxJbnRvVmlldyh7YmVo"
    "YXZpb3I6InNtb290aCIsYmxvY2s6ImNlbnRlciJ9KX0KfSk7Cgpjb25zdCBpbWdUYWc9aD0+aC5oYXNJbWFnZT9gPGltZyBjbGFz"
    "cz0iaHdpbWciIGFsdD0i2LnaqdizINiq2qnZhNuM2YEiIGRhdGEtaW1nPSIke2guaWR9fCR7aC52fSI+YDoiIjsKY29uc3QgaHdI"
    "YXNJbWFnZT1oPT4hIWguaGFzSW1hZ2U7CmNvbnN0IGltZ0NhY2hlPXt9OwpmdW5jdGlvbiBoeWRyYXRlSW1ncyhyb290KXsKICBy"
    "b290LnF1ZXJ5U2VsZWN0b3JBbGwoImltZ1tkYXRhLWltZ10iKS5mb3JFYWNoKGFzeW5jIGltPT57CiAgICBjb25zdCBrZXk9aW0u"
    "ZGF0YXNldC5pbWc7aWYoaW1nQ2FjaGVba2V5XSl7aW0uc3JjPWltZ0NhY2hlW2tleV07cmV0dXJufQogICAgdHJ5e2NvbnN0IHI9"
    "YXdhaXQgZmV0Y2goIi9hcGkvaHdpbWcvIitlbmNvZGVVUklDb21wb25lbnQoa2V5LnNwbGl0KCJ8IilbMF0pLHtoZWFkZXJzOntB"
    "dXRob3JpemF0aW9uOiJCZWFyZXIgIitzZXNzLnRva2VufX0pOwogICAgICBpZighci5vaylyZXR1cm47aW1nQ2FjaGVba2V5XT1V"
    "UkwuY3JlYXRlT2JqZWN0VVJMKGF3YWl0IHIuYmxvYigpKTtpbS5zcmM9aW1nQ2FjaGVba2V5XX1jYXRjaChfKXt9CiAgfSk7Cn0K"
    "ZnVuY3Rpb24gcmVuZGVyUEh3KCl7Y29uc3QgbGlzdD0oUy5ob21ld29ya3N8fFtdKS5zbGljZSgpLnNvcnQoKGEsYik9PmIuc2hv"
    "d0F0LWEuc2hvd0F0KTtpZihzZXRIVE1MKCQoInBIdyIpLGh3UGFyZW50SFRNTChsaXN0KSkpaHlkcmF0ZUltZ3MoJCgicEh3Iikp"
    "fQpmdW5jdGlvbiByZW5kZXJUSHcoKXtod0FsbD0oUy5ob21ld29ya3N8fFtdKS5zbGljZSgpLnNvcnQoKGEsYik9PmIuY3JlYXRl"
    "ZC1hLmNyZWF0ZWQpO3NldEhUTUwoJCgidEh3IiksaHdUZWFjaGVySFRNTChod0FsbCkpfQpjb25zdCBod09wcz17CiAgc2F2ZTpw"
    "PT5hcGkoIi9hcGkvaG9tZXdvcmsiLHApLAogIGRlbDppZD0+YXBpKCIvYXBpL2hvbWV3b3JrL2RlbGV0ZSIse2lkfSksCiAgc2hv"
    "dzooaWQsbXMpPT5hcGkoIi9hcGkvaG9tZXdvcmsvc2hvdyIse2lkLHNob3dBdDptc30pCn07CgovLyA9PT09PT09INin2KzYsdin"
    "ID09PT09PT0KZnVuY3Rpb24gcmVuZGVyKCl7CiAgaWYoIXNlc3MpcmV0dXJuOwogIHNlc3Mucm9sZT09PSJwYXJlbnQiP3JlbmRl"
    "clBhcmVudCgpOnJlbmRlclRlYWNoZXIoKTsKfQphc3luYyBmdW5jdGlvbiBlbnRlcigpewogIGlmKCFzZXNzKXtzaG93KCJsb2dp"
    "biIpO3JldHVybn0KICBzaG93KHNlc3Mucm9sZT09PSJwYXJlbnQiPyJwYXJlbnQiOiJ0ZWFjaGVyIik7CiAgUz1udWxsOwogIHRy"
    "eXtTPWF3YWl0IGFwaSgiL2FwaS9zdGF0ZSIpfWNhdGNoKF8pe3JldHVybn0KICBpZihzZXNzLnJvbGUhPT0icGFyZW50Iil7Zmls"
    "bFNldHRpbmdzKCk7cmVzZXRId0Zvcm0oKX0KICByZW5kZXIoKTsKfQpzZXRJbnRlcnZhbCgoKT0+eyQoInBDbG9jayIpLnRleHRD"
    "b250ZW50PSQoInRDbG9jayIpLnRleHRDb250ZW50PW5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKCJlbi1HQiIpfSwxMDAw"
    "KTsKZW50ZXIoKTsKPC9zY3JpcHQ+CjwvYm9keT4KPC9odG1sPgo="
)


def load_page():
    try:
        with open(PAGE, "rb") as f:
            return f.read()
    except Exception:
        return base64.b64decode(EMBEDDED_PAGE)


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "Portal"

    def log_message(self, *a):
        pass

    # --- پاسخ‌ها
    def send_json(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def read_body(self, limit=20000):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if n > limit:
            if n <= 20000000:          # بدنه را بخوان و دور بریز تا اتصال سالم بماند
                left = n
                while left > 0:
                    chunk = self.rfile.read(min(65536, left))
                    if not chunk:
                        break
                    left -= len(chunk)
            else:
                self.close_connection = True
            return None
        raw = self.rfile.read(n) if n else b""
        try:
            return json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            return {}

    def auth(self):
        h = self.headers.get("Authorization", "")
        if h.startswith("Bearer "):
            return sessions.get(h[7:])
        return None

    # --- روش‌ها
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        self.route("GET")

    def do_POST(self):
        self.route("POST")

    def route(self, method):
        url = self.path.split("?")[0]
        try:
            if method == "GET" and url in ("/", "/index.html", "/parent-portal.html"):
                b = load_page()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)
                return
            if not url.startswith("/api/"):
                return self.send_json(404, {"error": "پیدا نشد"})
            with LOCK:
                self.api(method, url)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            traceback.print_exc()
            try:
                self.send_json(500, {"error": "خطای سرور (" + type(e).__name__ + ": " + str(e)[:120] + ")"})
            except Exception:
                pass

    def api(self, method, url):
        if method == "POST" and url == "/api/login":
            ip = self.client_address[0]
            if too_many(ip):
                return self.send_json(429, {"error": "تلاش‌های زیاد؛ چند دقیقه بعد دوباره امتحان کنید."})
            b = self.read_body()
            if b is None:
                return self.send_json(413, {"error": "درخواست بزرگ است."})
            role = b.get("role")
            if role == "parent":
                name = norm(b.get("name"))
                if not name:
                    return self.send_json(400, {"error": "نام و نام خانوادگی دانش‌آموز را وارد کنید."})
                if not safe_eq(fa2en(str(b.get("code") or "").strip()), STUDENT_CODE):
                    failed(ip)
                    return self.send_json(401, {"error": "کد ورود اشتباه است."})
                if name not in state["students"]:
                    state["students"][name] = {"present": None, "call": None}
                    persist()
                token = secrets.token_hex(24)
                sessions[token] = {"role": "parent", "name": name}
                return self.send_json(200, {"token": token, "role": "parent", "name": name})
            if role == "teacher":
                if norm(b.get("name")) == norm(TEACHER["name"]) and safe_eq(fa2en(str(b.get("pass") or "").strip()), TEACHER["pass"]):
                    token = secrets.token_hex(24)
                    sessions[token] = {"role": "teacher"}
                    return self.send_json(200, {"token": token, "role": "teacher", "name": TEACHER["name"]})
                failed(ip)
                return self.send_json(401, {"error": "نام یا رمز عبور اشتباه است."})
            return self.send_json(400, {"error": "درخواست نامعتبر"})

        s = self.auth()
        if not s:
            return self.send_json(401, {"error": "وارد نشده‌اید."})

        if method == "GET" and url.startswith("/api/hwimg/"):
            from urllib.parse import unquote
            hid = unquote(url[len("/api/hwimg/"):])
            h = next((x for x in state["homeworks"] if x["id"] == hid), None)
            if not h or not h.get("image") or (s["role"] == "parent" and h["showAt"] > time.time() * 1000):
                return self.send_json(404, {"error": "پیدا نشد"})
            buf = base64.b64decode(h["image"].split(",", 1)[1])
            self.send_response(200)
            self.send_header("Content-Type", "image/jpeg")
            self.send_header("Cache-Control", "private, max-age=3600")
            self.send_header("Content-Length", str(len(buf)))
            self.end_headers()
            self.wfile.write(buf)
            return

        if method == "GET" and url == "/api/state":
            st = dict(state["set"])
            now_ms = time.time() * 1000
            if s["role"] == "parent":
                me = state["students"].get(s["name"]) or {"present": None, "call": None}
                return self.send_json(200, {"set": st, "now": now_hm(), "me": me,
                                            "homeworks": [pub_hw(h) for h in state["homeworks"] if h["showAt"] <= now_ms]})
            return self.send_json(200, {"set": st, "now": now_hm(), "students": state["students"],
                                        "homeworks": [pub_hw(h) for h in state["homeworks"]]})

        if s["role"] == "parent" and method == "POST" and url == "/api/call":
            b = self.read_body()
            if b is None:
                return self.send_json(413, {"error": "درخواست بزرگ است."})
            me = state["students"].get(s["name"])
            if not me:
                return self.send_json(404, {"error": "دانش‌آموز پیدا نشد."})
            if me.get("call") and me["call"]["status"] != "done":
                return self.send_json(409, {"error": "فراخوان قبلاً ارسال شده است."})
            if not in_window(state["set"]):
                return self.send_json(403, {"error": "الان خارج از بازه‌ی فراخوان است."})
            me["call"] = {"status": "sent", "time": int(time.time() * 1000)}
            persist()
            return self.send_json(200, {"ok": True})

        if s["role"] == "teacher" and method == "POST":
            if url == "/api/student":
                b = self.read_body() or {}
                x = state["students"].get(b.get("name"))
                if not x:
                    return self.send_json(404, {"error": "دانش‌آموز پیدا نشد."})
                a = b.get("action")
                if a == "here":
                    x["present"] = True
                elif a == "away":
                    x["present"] = False
                elif a in ("coming", "done"):
                    x["call"] = {"status": a, "time": int(time.time() * 1000)}
                else:
                    return self.send_json(400, {"error": "عملیات نامعتبر"})
                persist()
                return self.send_json(200, {"ok": True})

            if url == "/api/settings":
                b = self.read_body() or {}
                if not TIME_RE.match(str(b.get("from"))) or not TIME_RE.match(str(b.get("to"))):
                    return self.send_json(400, {"error": "مقادیر نامعتبر است."})
                state["set"].update({"from": b["from"], "to": b["to"]})
                persist()
                return self.send_json(200, {"ok": True})

            if url == "/api/homework":
                b = self.read_body(2000000)
                if b is None:
                    return self.send_json(413, {"error": "حجم عکس زیاد است؛ عکس کوچک‌تری انتخاب کنید."})
                title = str(b.get("title") or "").strip()
                desc = str(b.get("desc") or "").strip()
                if not title or len(title) > 200:
                    return self.send_json(400, {"error": "عنوان تکلیف نامعتبر است."})
                if len(desc) > 4000:
                    return self.send_json(400, {"error": "توضیحات خیلی طولانی است."})
                if not num(b.get("due")) or not num(b.get("showAt")):
                    return self.send_json(400, {"error": "مهلت یا زمان نمایش نامعتبر است."})
                img = b.get("image", "__keep__")
                if img not in ("__keep__", None):
                    if not isinstance(img, str) or len(img) > 1500000 or not IMG_RE.match(img):
                        return self.send_json(400, {"error": "عکس نامعتبر است."})
                h = None
                if b.get("id"):
                    h = next((x for x in state["homeworks"] if x["id"] == b["id"]), None)
                    if not h:
                        return self.send_json(404, {"error": "تکلیف پیدا نشد."})
                if not h:
                    h = {"id": secrets.token_hex(6), "created": int(time.time() * 1000), "image": None}
                    state["homeworks"].append(h)
                h.update({"title": title, "desc": desc, "due": b["due"], "showAt": b["showAt"], "v": int(time.time() * 1000)})
                if img != "__keep__":
                    h["image"] = img
                persist()
                return self.send_json(200, {"ok": True, "id": h["id"]})

            if url == "/api/homework/delete":
                b = self.read_body() or {}
                n = len(state["homeworks"])
                state["homeworks"] = [x for x in state["homeworks"] if x["id"] != b.get("id")]
                if len(state["homeworks"]) == n:
                    return self.send_json(404, {"error": "تکلیف پیدا نشد."})
                persist()
                return self.send_json(200, {"ok": True})

            if url == "/api/homework/show":
                b = self.read_body() or {}
                h = next((x for x in state["homeworks"] if x["id"] == b.get("id")), None)
                if not h:
                    return self.send_json(404, {"error": "تکلیف پیدا نشد."})
                if not num(b.get("showAt")):
                    return self.send_json(400, {"error": "زمان نمایش نامعتبر است."})
                h["showAt"] = b["showAt"]
                persist()
                return self.send_json(200, {"ok": True})

        return self.send_json(404, {"error": "پیدا نشد"})


def my_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return None


_srv = None


def run_forever():
    """برای اپ اندروید: سرور را اجرا می‌کند و تا stop_server() برنمی‌گردد."""
    global _srv
    _srv = ThreadingHTTPServer(("0.0.0.0", PORT), H)
    _srv.daemon_threads = True
    try:
        _srv.serve_forever()
    finally:
        _srv.server_close()
        _srv = None


def stop_server():
    if _srv is not None:
        _srv.shutdown()


if __name__ == "__main__":
    print("صفحه از:", PAGE if os.path.exists(PAGE) else "نسخه‌ی داخل همین فایل")
    print("پوشه‌ی ذخیره‌ی داده:", DATA_DIR)
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), H)
    srv.daemon_threads = True
    print("سرور روشن شد.")
    print("در همین گوشی بزنید:   http://localhost:%d" % PORT)
    ip = my_ip()
    if ip:
        print("از گوشی‌های دیگر (همان Wi-Fi): http://%s:%d" % (ip, PORT))
    print("برای خاموش کردن، دکمه‌ی توقف را بزنید.")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("خاموش شد.")
